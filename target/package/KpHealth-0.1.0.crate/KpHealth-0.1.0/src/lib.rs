//! # KpHealth
//!
//! A collection of utilities to enable KpHealth happened and efficient.

